import {defineConfig} from "vite"
import imbaPlugin from "imba/plugin"

export default defineConfig({
	plugins: [
		imbaPlugin()
	]
})